<?php
/**
 * 禹酒CRM 简体中文语言包
 * @module   User
 * @package  Lang
 * @author   xiaotan
 */
return array(
    
    'STOCK'					=>	'库存',
   
);