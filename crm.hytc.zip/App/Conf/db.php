<?php
return array(
'DB_TYPE'=>'mysql',
'DB_HOST'=>'localhost',
'DB_PORT'=>'3306',
'DB_NAME'=>'lx_crm_hytc',
'DB_USER'=>'root',
'DB_PWD'=>'159456',
'DB_PREFIX'=>'crm_',
);