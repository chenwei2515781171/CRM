<?php if (!defined('THINK_PATH')) exit();?><style>
    .row div{margin-bottom:20px;}
</style>
<div class="row">
    <div class="col-xs-12 col-lg-6">
        <a href="<?php echo U('customer/m_index');?>"><img src="__PUBLIC__/img/customer.png" class="pull-left" ></a>
        <h5><?php echo L('CUSTOMER');?></h5>
        <small><?php echo L('CUSTOMER_DESCRIBE');?></small>
        <!--p><a href="<?php echo U('task/add');?>"><?php echo L('CREATE_TASK');?></a> <?php echo L('OR');?> <a href="<?php echo U('task/index');?>"><?php echo L('SEE_TASK');?></a></p-->
    </div>
    <div class="col-xs-12 col-lg-6">
        <a href="<?php echo U('sales/m_index');?>"><img src="__PUBLIC__/img/business.png" class="pull-left" ></a>
        <h5>销售</h5>
        <small>销售人员可以在此方便的添加销售单</small>
        <!--p><a href="<?php echo U('task/add');?>"><?php echo L('CREATE_TASK');?></a> <?php echo L('OR');?> <a href="<?php echo U('task/index');?>"><?php echo L('SEE_TASK');?></a></p-->
    </div>
    <!--div class="col-xs-12 col-lg-6">
        <a href="<?php echo U('task/index');?>"><img src="__PUBLIC__/img/task.png" class="pull-left" ></a>
        <h5><?php echo L('TASK');?></h5>
        <small><?php echo L('TASK_DESCRIBE');?></small>
        <p><a href="<?php echo U('task/add');?>"><?php echo L('CREATE_TASK');?></a> <?php echo L('OR');?> <a href="<?php echo U('task/index');?>"><?php echo L('SEE_TASK');?></a></p>
    </div>
    <div class="col-xs-12 col-lg-6">
        <a href="<?php echo U('announcement/index');?>"><img src="__PUBLIC__/img/announcement.png" class="pull-left" ></a>
        <h5><?php echo L('ANNOUNCEMENT_MANAGEMENT');?></h5>
        <small><?php echo L('ANNOUNCEMENT_MANAGEMENT_DESCRIBE');?></small>
    </div>
	<div class="col-xs-12 col-lg-6">
		<a href="<?php echo U('leads/index');?>"><img src="__PUBLIC__/img/leads.png" class="pull-left"></a>
		<h5><?php echo L('LEADS');?></h5>
		<small><?php echo L('LEADS_DESCRIBE');?></small>
		<p><a href="<?php echo U('leads/add');?>"><?php echo L('CREATE_CLUE');?></a> <?php echo L('OR');?> <a href="<?php echo U('leads/index');?>"><?php echo L('SEE_CLUE');?></a></p>
	</div>
	<div class="col-xs-12 col-lg-6">
		<a href="<?php echo U('business/index');?>"><img src="__PUBLIC__/img/business.png" class="pull-left" ></a>
		<h5><?php echo L('BUSINESS');?></h5>
		<small><?php echo L('BUSINESS_DESCRIBE');?></small>
		<p><a href="<?php echo U('business/add');?>"><?php echo L('CREATE_BUSINESS');?></a> <?php echo L('OR');?> <a href="<?php echo U('business/index');?>"><?php echo L('SEE_BUSINESS');?></a></p>
	</div-->
    <!--div class="col-xs-12 col-lg-6">
        <img src="__PUBLIC__/img/customer.png" class="pull-left">
        <h5><?php echo L('CUSTOMER');?></h5>
        <small><?php echo L('CUSTOMER_DESCRIBE');?></small>
        <p><a href="<?php echo U('customer/add');?>"><?php echo L('CREATE_CUSTOMER');?></a> <?php echo L('OR');?> <a href="<?php echo U('customer/index');?>"><?php echo L('SEE_CUSTOMER');?></a></p>
    </div>
    <div class="col-xs-12 col-lg-6">
        <img src="__PUBLIC__/img/event.png" class="pull-left" >
        <h5><?php echo L('EVENT');?></h5>
        <small><?php echo L('EVENT_DESCRIBE');?></small>
        <p><a href="<?php echo U('event/add');?>"><?php echo L('CREATE_SCHEDULE');?></a> <?php echo L('OR');?> <a href="<?php echo U('event/index');?>"><?php echo L('SEE_SCHEDULE');?></a></p>
    </div>
    <div class="col-xs-12 col-lg-6">
        <img src="__PUBLIC__/img/finance.png" class="pull-left">
        <h5><?php echo L('FINANCE');?></h5>
        <small><?php echo L('FINANCE_DESCRIBE');?></small>
    </div>
    <div class="col-xs-12 col-lg-6">
        <img src="__PUBLIC__/img/knowledge.png" class="pull-left">
        <h5><?php echo L('KNOWLEDGE');?></h5>
        <small><?php echo L('KNOWLEDGE_DESCRIBE');?></small>
        <p><a href="<?php echo U('knowledge/add');?>"><?php echo L('CREATE_KNOWLEDGE');?></a> <?php echo L('OR');?> <a href="<?php echo U('knowledge/index');?>"><?php echo L('SEE_KNOWLEDGE');?></a></p>
    </div>
	<div class="col-xs-12 col-lg-6">
		<img src="__PUBLIC__/img/event.png" class="pull-left" >
		<h5><?php echo L('WORK_LOG');?></h5>
		<small><?php echo L('LOG_DESCRIBE');?></small>
		<p><a href="<?php echo U('log/mylog_add');?>"><?php echo L('CREATE_SCHEDULE');?></a> <?php echo L('OR');?> <a href="<?php echo U('log/index');?>"><?php echo L('SEE_SCHEDULE');?></a></p>
	</div>
	<div class="col-xs-12 col-lg-6">
		<img src="__PUBLIC__/img/customer.png" class="pull-left">
		<h5><?php echo L('CUSTOMER');?></h5>
		<small><?php echo L('CUSTOMER_DESCRIBE');?></small>
		<p><a href="<?php echo U('customer/add');?>"><?php echo L('CREATE_CUSTOMER');?></a> <?php echo L('OR');?> <a href="<?php echo U('customer/index');?>"><?php echo L('SEE_CUSTOMER');?></a></p>
	</div-->
</div>